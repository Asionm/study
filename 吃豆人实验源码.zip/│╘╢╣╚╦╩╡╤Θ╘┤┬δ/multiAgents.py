# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util
from game import Agent
from time import sleep

class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """

    # 获取最近的豆的坐标 利用的是BFS算法
    def getNd(self,gameState):
        openT = []
        closeT = []
        direc = [[-1, 0], [1, 0], [0, 1], [0, -1]]  # 移动配置列表
        pacP = gameState.getPacmanPosition()  # 获取pacman的位置
        food = gameState.getFood()  # 食物布局
        openT.append(pacP)
        closeT.append(pacP)
        while not food[openT[0][0]][openT[0][1]] and openT:
            # print("openT:",openT)
            # print("closeT:",closeT,"\n")
            for i in direc:
                newP = (openT[0][0] + i[0], openT[0][1] + i[1])
                if 0 <= newP[0] < len(list(gameState.getFood())) \
                        and 0 <= newP[1] < len(gameState.getFood()[0]):  # 边界限制
                    if newP not in closeT:
                        closeT.append(newP)
                        openT.append(newP)
            openT.pop(0)  # 出队并入closeT
        # 拓展 0<=y<=7  0<=x<=23
        # 找到的话返回坐标
        else:
            return (openT[0][0], openT[0][1])

    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        getAction takes a GameState and returns some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()
        #获取合法路径 大概是获取可以往哪个方向移动 因为是有墙壁的 所以并不能往四个方向移动

        #获取最近的豆
        nearestP = self.getNd(gameState)

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action, nearestP) for action in legalMoves]
        #这里会遍历每个合法动作 并把动作传到evaluationFunction的函数中
        #evaluationFunction函数用于评分

        bestScore = max(scores)
        #这会选取分数最高的

        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        #获取分数最高的动作的索引 可能有多个相同的最高分

        chosenIndex = random.choice(bestIndices)  # Pick randomly among the best
        #在最高分数中随机选一个

        "Add more of your code here if you want to"
        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action, nearestP):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        #这个赋值 估计是根据action动作移动到另外一个位置
        currentPos = currentGameState.getPacmanPosition()
        newPos = successorGameState.getPacmanPosition()
        #获取移动后的位置


        newFood = successorGameState.getFood()
        #获取的是当前状态下食物的布局图 T代表有 F代表没有

        newGhostStates = successorGameState.getGhostStates()
        currScaredTimes = [ghostState.scaredTimer for ghostState in currentGameState.getGhostStates()]

        "*** YOUR CODE HERE ***"
        '''
        算法思路如下
        1. 利用BFS算法搜索出最近的食物的位置 并返回此位置
           利用这个位置 用贪婪算法来导航
        2. 当下一步遇到幽灵时 把此方向的分数设置为最小的
        '''
        #获取幽灵位置
        ghosstP = successorGameState.getGhostPositions()
        capsules = currentGameState.getCapsules()
        #遍历幽灵 若遇到幽灵 则优先逃命
        for i in ghosstP:
            if abs(newPos[0]-i[0]) + abs(newPos[1]-i[1]) <= 1:
                return -99999999
        else: #否则的话score等于此点到最近点的曼哈顿距离
            #若离胶囊的距离小于5 那么优先吃胶囊
            for i in capsules:
                if abs(newPos[0] - i[0]) + abs(newPos[1] - i[1]) <= 5:
                    if action == "Stop":  # 如果停止的话就把分数降低逼迫它移动 只有遇到幽灵才有机会停止
                        return -5000
                    return (5-(abs(newPos[0] - i[0]) + abs(newPos[1] - i[1])))

            if action == "Stop": #如果停止的话就把分数降低逼迫它移动 只有遇到幽灵才有机会停止
                return -5000
            else:
                #曼哈顿距离 贪婪算法
                return -(abs(newPos[0]-nearestP[0]) + abs(newPos[1]-nearestP[1]))

        # return successorGameState.getScore()
        #这好像返回的是全局的分数和上面好像没有联系




def scoreEvaluationFunction(currentGameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return currentGameState.getScore()


class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)


class MinimaxAgent(MultiAgentSearchAgent):
    """
    Your minimax agent (question 2)
    """
    '''
    下面的代码是确实有参考以下别人的，然后都是看了一两遍别人代码以及伪代码，然后自己写的
    参考的文章有：
    1.https://blog.csdn.net/Pericles_HAT/article/details/116901139
    2.https://blog.csdn.net/m0_48134027/article/details/120340931
    先前有设计了一个完全没有参考别人文章的算法，然后也能成功运行成功率和minimax差不多，但是最后发现
    编的时候忘记把幽灵的index改过来了，。。所以一直搜索的都是吃豆人本身，而且那份代码我写得很复杂。以
    至于最后在写alpha-beta时发现无从入手，所以就找了下网络上的文章，结果发现和我的有点不一样虽然思路
    是一样的。最后在尝试了一个下午后无法修改bug以及无法利用自身的minimax代码来编写alpha-beta算法所
    以放弃了自身方案。
    '''

    def max_value(self, state, depth, index=0): #获取最大层的score
        v = -float('inf')
        if state.isLose() or state.isWin() or depth == self.depth:
            # 设置超限条件
            return self.evaluationFunction(state), None #超限的话返回动作为空
        legalActions = state.getLegalActions(index)
        if "Stop" in legalActions:
            legalActions.remove("Stop")  #移除Stop，能防止一些傻瓜行为
        for action in legalActions:
            successor = state.generateSuccessor(index, action)
            # v = max(v, self.min_value(successor, depth=depth, index=index + 1)[0])  # 进入幽灵节点深度是不变的，只有再次进入吃豆人节点 深度才会加1
            temp = self.min_value(successor, depth=depth, index=index + 1)
            if temp > v: #为了能返回动作把max改成这样
                v = temp #对于min不用判断它的动作
                bestAction = action
            # 对于max开始的下一个肯定是幽灵1
        return v, bestAction  #注意返回的是数字，应该要带有action

    def min_value(self, state, depth, index): #获取最小层的score
        v = float('inf')
        i_num = state.getNumAgents()  # 获取agent数量
        if state.isLose() or state.isWin() or depth == self.depth:
            # 设置超限条件
            return self.evaluationFunction(state)
        legalActions = state.getLegalActions(index)
        for action in legalActions:
            successor = state.generateSuccessor(index, action)
            if i_num - 1 == index:  # 如果这是最后一个幽灵的话就用max
                v = min(v, self.max_value(successor, depth=depth + 1, index=0)[0])  # 如果是最后一个鬼节点了 那么下一个节点就要深度加1了
            else:  # 否则用min
                v = min(v, self.min_value(successor, depth=depth, index=index+1))
        return v

    def getAction(self, gameState):
        """
        Returns the minimax action from the current gameState using self.depth
        and self.evaluationFunction.

        Here are some method calls that might be useful when implementing minimax.

        gameState.getLegalActions(agentIndex):
        Returns a list of legal actions for an agent
        agentIndex=0 means Pacman, ghosts are >= 1

        gameState.generateSuccessor(agentIndex, action):
        Returns the successor game state after an agent takes an action

        gameState.getNumAgents():
        Returns the total number of agents in the game

        gameState.isWin():
        Returns whether or not the game state is a winning state

        gameState.isLose():
        Returns whether or not the game state is a losing state
        """
        "*** YOUR CODE HERE ***"

        #util.raiseNotDefined()

        return self.max_value(gameState, 0)[1]  # 根节点的depth为0


class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """
    '''
    AlphaBeta算法剪枝后发现 在深度为4时在minimaxClassic图中其运行时间为8秒，而未剪枝前是15秒，
    得到了一定的提升。而在smallClassic图中，其提升速度明显。然而两者在smallClassic图中获胜概率
    为0，这应该和评估函数有关。
    '''

    alpha = -float('inf')  # alpha初始状态为负无穷
    beta = float('inf')  # beta初始为正无穷
    def getAction(self, gameState):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"
        # util.raiseNotDefined()
        # 从根节点开始展开，求MAX值，注意：返回值中下标为1的项才是行动内容
        return self.max_value(gameState, 0)[1]  # 根节点的depth为0

    def max_value(self, state, depth, index=0):
        v = -float('inf')
        if state.isLose() or state.isWin() or depth == self.depth:
            # 设置超限条件
            return self.evaluationFunction(state), None  # 超限的话返回动作为空
        legalActions = state.getLegalActions(index)
        if "Stop" in legalActions:
            legalActions.remove("Stop")  # 移除Stop，能防止一些傻瓜行为
        for action in legalActions:
            successor = state.generateSuccessor(index, action)
            # v = max(v, self.min_value(successor, depth=depth, index=index + 1)[0])  # 进入幽灵节点深度是不变的，只有再次进入吃豆人节点 深度才会加1
            temp = self.min_value(successor, depth=depth, index=index + 1)
            if temp > v:  # 为了能返回动作把max改成这样
                v = temp  # 对于min不用判断它的动作
                bestAction = action
            if v > self.beta:  # 如果v>beta那么就无需继续探索了
                return v, bestAction
            self.alpha = max(self.alpha, v)  # 若v比alpha大 则更新alpha
            # 对于max开始的下一个肯定是幽灵1
        return v, bestAction  # 注意返回的是数字，应该要带有action

    def min_value(self, state, depth, index):
        v = float('inf')
        i_num = state.getNumAgents()  # 获取agent数量
        if state.isLose() or state.isWin() or depth == self.depth:
            # 设置超限条件
            return self.evaluationFunction(state)
        legalActions = state.getLegalActions(index)
        for action in legalActions:
            successor = state.generateSuccessor(index, action)
            if i_num - 1 == index:  # 如果这是最后一个幽灵的话就用max
                v = min(v, self.max_value(successor, depth=depth + 1, index=0)[0])  # 如果是最后一个鬼节点了 那么下一个节点就要深度加1了
                if v < self.alpha:  # 如果v<alpha则无需继续探索
                    return v
                self.beta = min(self.beta, v)  # 若v比beta小则更新
            else:  # 否则用min
                v = min(v, self.min_value(successor, depth=depth, index=index + 1))
                if v > self.beta:  # 由于这种情况仍然是min的所以用beta
                    return v
                self.alpha = max(self.alpha, v)
        return v

def betterEvaluationFunction(currentGameState):
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 4).

    DESCRIPTION: <write something here so we know what you did>
    """
    "*** YOUR CODE HERE ***"
    util.raiseNotDefined()


# Abbreviation
better = betterEvaluationFunction
