import sys
from optparse import OptionParser
import pandas


test = [1,2,5]
print(test)
test.remove(5)
print(test)


